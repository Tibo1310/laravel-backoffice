<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UtilisateurController;
use App\Http\Controllers\CommandeController;
use App\Http\Controllers\ProduitController;

// Route pour afficher la liste des utilisateurs
Route::get('/utilisateurs', [UtilisateurController::class, 'index'])->name('index');

// Route pour afficher le formulaire de création d'un utilisateur
Route::get('/utilisateurs/create', [UtilisateurController::class, 'create'])->name('create');

// Route pour enregistrer un nouvel utilisateur
Route::post('/utilisateurs', [UtilisateurController::class, 'store'])->name('store');

// Route pour afficher les détails d'un utilisateur
Route::get('/utilisateurs/{utilisateur}', [UtilisateurController::class, 'show'])->name('show');

// Route pour afficher le formulaire de modification d'un utilisateur
Route::get('/utilisateurs/{utilisateur}/edit', [UtilisateurController::class, 'edit'])->name('edit');

// Route pour mettre à jour un utilisateur existant
Route::put('/utilisateurs/{utilisateur}', [UtilisateurController::class, 'update'])->name('update');

// Route pour supprimer un utilisateur
Route::delete('/utilisateurs/{utilisateur}', [UtilisateurController::class, 'destroy'])->name('destroy');

// Route pour afficher la liste des commandes pour un utilisateur donné
Route::get('/utilisateurs/{utilisateur}/commandes', [CommandeController::class, 'index'])->name('commandes_index');

// Route pour afficher le formulaire de création d'une commande pour un utilisateur donné
Route::get('/utilisateurs/{utilisateur}/commandes/create', [CommandeController::class, 'create'])->name('commandes_create');

// Route pour enregistrer une nouvelle commande pour un utilisateur donné
Route::post('/utilisateurs/{utilisateur}/commandes', [CommandeController::class, 'store'])->name('commandes_store');

// Route pour afficher les détails d'une commande pour un utilisateur donné
Route::get('/utilisateurs/{utilisateur}/commandes/{commande}', [CommandeController::class, 'show'])->name('commandes_show');

// Route pour afficher le formulaire de modification d'une commande pour un utilisateur donné
Route::get('/utilisateurs/{utilisateur}/commandes/{commande}/edit', [CommandeController::class, 'edit'])->name('commandes_edit');

// Route pour mettre à jour une commande existante pour un utilisateur donné
Route::put('/utilisateurs/{utilisateur}/commandes/{commande}', [CommandeController::class, 'update'])->name('commandes_update')->whereNumber('utilisateur')->whereNumber('commande');

// Route pour supprimer une commande pour un utilisateur donné
Route::delete('/utilisateurs/{utilisateur}/commandes/{commande}', [CommandeController::class, 'destroy'])->name('commandes_destroy');