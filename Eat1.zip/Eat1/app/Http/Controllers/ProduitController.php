<?php

namespace App\Http\Controllers;

use App\Models\Produit;
use Illuminate\Http\Request;

class ProduitController extends Controller
{
    public function index()
    {
        $produits = Produit::all();
        return view('produits.index', compact('produits'));
    }

    public function create()
    {
        return view('produits.create');
    }

    public function store(Request $request, Utilisateur $utilisateur)
    {
        $request->validate([
            'date' => 'required|date',
            'montant' => 'required|numeric|min:0',
            'produits' => 'required|array',
        ]);
    
        $commande = new Commande([
            'utilisateur_id' => $utilisateur->id,
            'date' => $request->date,
            'montant' => $request->montant,
            'produits' => $request->produits,
        ]);
        $commande->save();
    
        $commande->produits()->attach($request->produits);
    
        return redirect()->route('show', ['utilisateur' => $utilisateur->id]);
    }
    

    public function edit(Produit $produit)
    {
        return view('produits.edit', compact('produit'));
    }

    public function update(Request $request, Produit $produit)
    {
        $request->validate([
            'nom' => 'required',
            'description' => 'required',
        ]);

        $produit->update($request->all());

        return redirect()->route('produits.index')
            ->with('success', 'Produit modifié avec succès.');
    }

    public function destroy(Produit $produit)
    {
        $produit->delete();

        return redirect()->route('produits.index')
            ->with('success', 'Produit supprimé avec succès.');
    }
}
