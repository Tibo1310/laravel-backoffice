<?php

namespace App\Http\Controllers;

use App\Models\Commande;
use App\Models\Produit;
use App\Models\Utilisateur;
use Illuminate\Http\Request;


class CommandeController extends Controller
{
    public function index()
    {
        $commandes = Commande::all();
        return view('commandes_index', compact('commandes'));
    }

    public function create(Utilisateur $utilisateur)
    {
        $produits = Produit::all();
        return view('commandes_create', compact('utilisateur', 'produits'));
    }
    
    public function store(Request $request, Utilisateur $utilisateur)
    {
        $validatedData = $request->validate([
            'date' => 'required|date',
            'montant' => 'required|numeric|min:0.01',
            'produits' => 'required|array|min:1',
            'produits.*' => 'exists:produits,id',
        ]);
    
        $commande = new Commande([
            'date' => $validatedData['date'],
            'montant' => $validatedData['montant'],
        ]);
    
        $commande->utilisateur()->associate($utilisateur);
        $commande->save();
    
        $commande->produits()->sync($validatedData['produits']);
    
        // Rediriger l'utilisateur vers la page d'accueil avec le paramètre utilisateur
        return redirect()->route('index', ['utilisateur' => $utilisateur->id]);
    }

    public function edit(Utilisateur $utilisateur, Commande $commande)
    {
        return view('commandes_edit', compact('utilisateur', 'commande'));
    }
    
    public function update(Request $request, Utilisateur $utilisateur, Commande $commande)
    {
        $validatedData = $request->validate([
            'date' => 'required|date',
            'montant' => 'required|numeric|min:0.01',
        ]);
    
        $commande->date = $request->input('date');
        $commande->montant = $request->input('montant');
    
        $commande->save();
    
        return redirect()->route('commandes_show', ['utilisateur' => $utilisateur->id, 'commande' => $commande->id])->with('success', 'La commande a été mise à jour avec succès.');
    }

    public function destroy($utilisateur_id, $commande_id)
    {
        $commande = Commande::findOrFail($commande_id);
        $commande->delete();
    
        return redirect()->route('index', $utilisateur_id);
    }
    

    public function show($utilisateur_id, $commande_id)
    {
        $commande = Commande::findOrFail($commande_id);
        $produits = $commande->produits;
    
        return view('commandes_show', compact('commande', 'produits'));
    }
}
