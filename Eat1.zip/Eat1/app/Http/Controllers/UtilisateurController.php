<?php

namespace App\Http\Controllers;

use App\Models\Utilisateur;
use Illuminate\Http\Request;

class UtilisateurController extends Controller
{
    public function index()
    {
        $utilisateurs = Utilisateur::all();
        return view('index', compact('utilisateurs'));
    }

    public function create()
    {
        $utilisateur = new Utilisateur();
        return view('create', compact('utilisateur'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'nom' => 'required',
            'prenom' => 'required',
            'email' => 'required|email|unique:utilisateurs,email',
        ]);

        $utilisateur = Utilisateur::create($request->all());

        return redirect()->route('index')
            ->with('success', 'Utilisateur créé avec succès.');
    }

    public function edit(Utilisateur $utilisateur)
    {
        return view('edit', compact('utilisateur'));
    }

    public function update(Request $request, Utilisateur $utilisateur)
    {
        $request->validate([
            'nom' => 'required',
            'prenom' => 'required',
            'email' => 'required|email|unique:utilisateurs,email,' . $utilisateur->id,
        ]);

        $utilisateur->update($request->all());

        return redirect()->route('index')
            ->with('success', 'Utilisateur modifié avec succès.');
    }

    public function destroy(Utilisateur $utilisateur)
    {
        $utilisateur->delete();

        return redirect()->route('index')
            ->with('success', 'Utilisateur supprimé avec succès.');
    }
}
