<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Commande extends Model
{
    use HasFactory;

    protected $table = 'commandes';
    protected $fillable = ['utilisateur_id', 'date', 'montant'];
    protected $casts = [
        'produits' => 'array',
    ];

    public function utilisateur()
    {
        return $this->belongsTo(Utilisateur::class);
    }

    public function produits()
    {
        return $this->belongsToMany(Produit::class)->withPivot('quantite', 'nom');
    }

        public function ajouterProduit(Produit $produit)
    {
        $this->produits()->attach($produit->id);
    }

    public static function boot()
{
    parent::boot();

    static::creating(function ($commande) {
        $commande->date = $commande->date ?? now()->toDateString();
    });
}

}
