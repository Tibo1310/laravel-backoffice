

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Détails de la commande numéro <?php echo e($commande->id); ?></h2>

        <p>Date de création : <?php echo e($commande->created_at); ?></p>
        <p>Montant : <?php echo e($commande->montant); ?></p>

        <?php if(!empty($produits)): ?>
            <h2>Produits associés :</h2>
            <ul>
                <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($produit->nom); ?> (<?php echo e($produit->pivot->quantite); ?>)</li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <p>Aucun produit associé à cette commande.</p>
        <?php endif; ?>

        <a href="<?php echo e(route('index')); ?>" class="btn btn-primary">Retour</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Eat1\resources\views/commandes_show.blade.php ENDPATH**/ ?>