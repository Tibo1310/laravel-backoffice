

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Liste des utilisateurs</div>
                    <div class="col-md-6 text-right">
                        <a class="btn btn-primary" href="<?php echo e(route('create')); ?>">Créer un utilisateur</a>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Nom</th>
                                    <th>Prénom</th>
                                    <th>Email</th>
                                    <th>Numéro de commande</th>
                                    <th>Date de création</th>
                                    <th>Date de mise à jour</th>
                                    <th>Montant</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $utilisateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $utilisateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($utilisateur->nom); ?></td>
                                        <td><?php echo e($utilisateur->prenom); ?></td>
                                        <td><?php echo e($utilisateur->email); ?></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td>
                                        <td>
                                            <a class="btn btn-success" href="<?php echo e(route('commandes_create', $utilisateur->id)); ?>">Créer une commande</a>
                                            <a class="btn btn-primary" href="<?php echo e(route('edit', $utilisateur->id)); ?>">Modifier l'utilisateur</a>
                                            <form action="<?php echo e(route('destroy', $utilisateur->id)); ?>" method="POST" style="display: inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur et ses commandes ?')">Supprimer l'utilisateur</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php $__currentLoopData = $utilisateur->commandes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td><?php echo e($commande->id); ?></td>
                                            <td><?php echo e($commande->created_at); ?></td>
                                            <td><?php echo e($commande->updated_at); ?></td>
                                            <td><?php echo e($commande->montant); ?></td>
                                            <td>
                                                <a class="btn btn-primary" href="<?php echo e(route('commandes_edit', [$utilisateur->id, $commande->id])); ?>">Modifier la commande</a>
                                                <form action="<?php echo e(route('commandes_destroy', [$utilisateur->id, $commande->id])); ?>" method="POST" style="display: inline-block;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette commande ?')">Supprimer la commande</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Eat1\resources\views/index.blade.php ENDPATH**/ ?>