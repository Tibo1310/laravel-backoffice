

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Liste des utilisateurs</div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Nom</th>
                                    <th>Prénom</th>
                                    <th>Email</th>
                                    <th>Numéro de commande</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $utilisateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $utilisateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($utilisateur->nom); ?></td>
                                        <td><?php echo e($utilisateur->prenom); ?></td>
                                        <td><?php echo e($utilisateur->email); ?></td>
                                        <td><?php echo e($utilisateur->numero_commande); ?></td>
                                        <td>
                                            <a class="btn btn-primary" href="<?php echo e(route('utilisateurs.edit', $utilisateur->id)); ?>">Modifier</a>
                                            <form action="<?php echo e(route('utilisateurs.destroy', $utilisateur->id)); ?>" method="POST" style="display: inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">Supprimer</button>
                                            </form>
                                            <a class="btn btn-success" href="<?php echo e(route('commandes.create', $utilisateur->id)); ?>">Créer commande</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eat1\resources\views/utilisateurs_index.blade.php ENDPATH**/ ?>