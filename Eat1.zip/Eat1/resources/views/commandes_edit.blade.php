@extends('app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Modifier la commande</div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('commandes_update', ['utilisateur' => $utilisateur->id, 'commande' => $commande->id]) }}">
                            @csrf
                            @method('PUT')
                            <input type="hidden" name="commande_id" value="{{$commande->id}}">

                            <label for="numero" class="col-md-4 col-form-label text-md-right">Numéro de la commande</label>
                                <div class="col-md-6">
                                    <input id="numero" type="text" class="form-control" name="numero" value="{{$commande->id}}" disabled>
                                </div>
                            </div>



                            <div class="form-group row">
                                <label for="date" class="col-md-4 col-form-label text-md-right">Date</label>
                                <div class="col-md-6">
                                    <input id="date" type="date" class="form-control @error('date') is-invalid @enderror" name="date" value="{{ $commande->date }}" required>
                                    @error('date')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="montant" class="col-md-4 col-form-label text-md-right">Montant</label>
                                <div class="col-md-6">
                                    <input id="montant" type="text" class="form-control @error('montant') is-invalid @enderror" name="montant" value="{{ $commande->montant }}" required>
                                    @error('montant')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="produits" class="col-md-4 col-form-label text-md-right">Produits</label>
                                <div class="col-md-6">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Produit</th>
                                                <th>Quantité</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        @if(!empty($commande->produits))
                                        @foreach($commande->produits as $produit)
                                            <tr>
                                                <td>{{ $produit->nom }}</td>
                                                <td>
                                                    <input id="produit_{{ $produit->id }}" type="number" min="0" class="form-control @error('produit_'.$produit->id) is-invalid @enderror" name="produit_{{ $produit->id }}" value="{{ $produit->pivot->quantite }}" required>
                                                    @error('produit_'.$produit->id)
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </td>
                                            </tr>
                                        @endforeach
                                        @endif
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">Enregistrer</button>
                                    <a href="{{ route('index') }}" class="btn btn-danger">Annuler</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
