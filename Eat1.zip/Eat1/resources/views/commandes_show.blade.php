@extends('app')

@section('content')
    <div class="container">
        <h2>Détails de la commande numéro {{$commande->id}}</h2>

        <p>Date de création : {{ $commande->created_at }}</p>
        <p>Montant : {{ $commande->montant }}</p>

        @if(!empty($produits))
            <h2>Produits associés :</h2>
            <ul>
                @foreach($produits as $produit)
                <li>{{ $produit->pivot->nom }} ({{ $produit->pivot->quantite }})</li>
                @endforeach
            </ul>
        @else
            <p>Aucun produit associé à cette commande.</p>
        @endif

        <a href="{{ route('index') }}" class="btn btn-primary">Retour</a>
    </div>
@endsection
