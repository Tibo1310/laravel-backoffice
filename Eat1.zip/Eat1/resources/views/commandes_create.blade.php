@extends('app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Créer une commande pour {{ $utilisateur->prenom }} {{ $utilisateur->nom }}</div>

                    <div class="card-body">
                    <form action="{{ route('commandes_store', ['utilisateur' => $utilisateur->id]) }}" method="POST">
                        @csrf
                        <input type="hidden" name="utilisateur_id" value="{{ $utilisateur->id }}">


                            <div class="form-group row">
                                <label for="date" class="col-md-4 col-form-label text-md-right">Date</label>

                                <div class="col-md-6">
                                    <input id="date" type="date" class="form-control @error('date') is-invalid @enderror" name="date" value="{{ old('date', now()->toDateString()) }}" required autofocus>

                                    @error('date')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="montant" class="col-md-4 col-form-label text-md-right">Montant</label>

                                <div class="col-md-6">
                                    <input id="montant" type="number" step="0.1" class="form-control @error('montant') is-invalid @enderror" name="montant" value="{{ old('montant') }}" required>

                                    @error('montant')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="produits" class="col-md-4 col-form-label text-md-right">Produits</label>

                                <div class="col-md-6">
                                    <input type="hidden" name="produits" id="produits" value="{{ old('produits') }}">
                                    <select id="produits" class="form-control @error('produits') is-invalid @enderror" name="produits[]" multiple>
                                        @foreach($produits as $produit)
                                            <option value="{{ $produit->id }}">{{ $produit->nom }}</option>
                                        @endforeach
                                    </select>

                                    @error('produits')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>


                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        Créer
                                    </button>
                                    <a href="{{ route('index', ['utilisateur' => $utilisateur->id]) }}" class="btn btn-secondary">
                                        Annuler
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

<script>
    const produitsSelect = document.querySelector('#produits');
    const produitsOptions = document.querySelectorAll('#produits option');

    produitsSelect.value = Array.from(produitsOptions)
        .filter(option => option.selected)
        .map(option => option.value)
        .join(',');
</script>
