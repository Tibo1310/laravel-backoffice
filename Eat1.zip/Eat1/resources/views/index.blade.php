@extends('app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Liste des utilisateurs</div>
                    <div class="col-md-6 text-right">
                        <a class="btn btn-primary" href="{{ route('create') }}">Créer un utilisateur</a>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Nom</th>
                                    <th>Prénom</th>
                                    <th>Email</th>
                                    <th>Numéro de commande</th>
                                    <th>Date de création</th>
                                    <th>Date de mise à jour</th>
                                    <th>Montant</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($utilisateurs as $utilisateur)
                                    <tr>
                                        <td>{{ $utilisateur->nom }}</td>
                                        <td>{{ $utilisateur->prenom }}</td>
                                        <td>{{ $utilisateur->email }}</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td>
                                        <td>
                                            <a class="btn btn-success" href="{{ route('commandes_create', $utilisateur->id) }}">Créer une commande</a>
                                            <a class="btn btn-primary" href="{{ route('edit', $utilisateur->id) }}">Modifier l'utilisateur</a>
                                            <form action="{{ route('destroy', $utilisateur->id) }}" method="POST" style="display: inline-block;">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur et ses commandes ?')">Supprimer l'utilisateur</button>
                                            </form>
                                        </td>
                                    </tr>
                                    @foreach ($utilisateur->commandes as $commande)
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>{{ $commande->id }}</td>
                                            <td>{{ $commande->created_at }}</td>
                                            <td>{{ $commande->updated_at }}</td>
                                            <td>{{ $commande->montant }}</td>
                                            <td>
                                                <a class="btn btn-primary" href="{{ route('commandes_edit', [$utilisateur->id, $commande->id]) }}">Modifier la commande</a>
                                                <form action="{{ route('commandes_destroy', [$utilisateur->id, $commande->id]) }}" method="POST" style="display: inline-block;">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette commande ?')">Supprimer la commande</button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
